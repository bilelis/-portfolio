# TechGear Pro Store

## Project Resources

This folder contains the development resources for the TechGear Pro Store website project.

### Contents:
- Project documentation
- Design files
- Source code
- Asset files

### Technologies Used:
- HTML5
- CSS3
- JavaScript (Vanilla)
- Responsive Design

### Developer:
Bilel Ayari

For more information, visit the live project at [TechGear Pro Store](/projects/techgear-pro)