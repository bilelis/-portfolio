# SportZone Equipment

## Project Resources

This folder contains the development resources for the SportZone Equipment website project.

### Contents:
- Project documentation
- Design files
- Source code
- Asset files

### Technologies Used:
- HTML5
- CSS3
- JavaScript (Vanilla)
- Responsive Design

### Developer:
Bilel Ayari

For more information, visit the live project at [SportZone Equipment](/projects/sportzone-equipment)