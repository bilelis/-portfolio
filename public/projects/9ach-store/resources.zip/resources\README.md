# 9ach - Premium Streetwear Collection

## Project Resources

This folder contains the development resources for the 9ach e-commerce website project.

### Contents:
- Project documentation
- Design files
- Source code
- Asset files

### Technologies Used:
- HTML5
- CSS3
- JavaScript (Vanilla)
- Responsive Design
- Font Awesome Icons
- Google Fonts

### Developer:
Bilel Ayari

For more information, visit the live project at [9ach Store](/projects/9ach-store)